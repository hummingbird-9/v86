/**
 * @define {boolean}
 * Overridden for production by closure compiler
 */
var DEBUG = true;
